-- =====================================================
-- HOSPITALFLOW360
-- REVENUE LEAKAGE ANALYSIS
-- =====================================================

SELECT
    d.department_name,

    SUM(b.net_amount)
    AS estimated_revenue_loss

FROM billing b

JOIN appointments a
ON b.appointment_id = a.appointment_id

JOIN departments d
ON a.department_id = d.department_id

WHERE a.status = 'No Show'

GROUP BY d.department_name

ORDER BY estimated_revenue_loss DESC;