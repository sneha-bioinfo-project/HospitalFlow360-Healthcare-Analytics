-- =====================================================
-- HOSPITALFLOW360
-- NO-SHOW ANALYSIS
-- =====================================================

-- -----------------------------------------------------
-- Query 1: No-show Rate by Department
-- -----------------------------------------------------

SELECT
    d.department_name,

    COUNT(
        CASE
            WHEN a.status = 'No Show' THEN 1
        END
    ) * 100.0 / COUNT(*) AS noshow_rate

FROM appointments a

JOIN departments d
ON a.department_id = d.department_id

GROUP BY d.department_name

ORDER BY noshow_rate DESC;


-- -----------------------------------------------------
-- Query 2: No-show Rate by Appointment Time Slot
-- -----------------------------------------------------

SELECT
    appointment_hour_band,

    COUNT(*) AS total_appointments,

    COUNT(
        CASE
            WHEN status = 'No Show' THEN 1
        END
    ) * 100.0 / COUNT(*) AS noshow_rate

FROM appointments

GROUP BY appointment_hour_band

ORDER BY noshow_rate DESC;