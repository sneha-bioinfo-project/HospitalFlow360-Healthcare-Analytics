-- =====================================================
-- HOSPITALFLOW360
-- DOCTOR EFFICIENCY ANALYSIS
-- =====================================================

SELECT
    doctor_id,

    AVG(length_of_stay)
    AS avg_los

FROM admissions

GROUP BY doctor_id

ORDER BY avg_los DESC;