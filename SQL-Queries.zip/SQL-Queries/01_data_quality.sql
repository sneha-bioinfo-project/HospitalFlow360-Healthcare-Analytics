-- =====================================================
-- HOSPITALFLOW360
-- DATA QUALITY ANALYSIS
-- =====================================================

-- -----------------------------------------------------
-- Query 1: Missing Insurance Information
-- -----------------------------------------------------

SELECT *
FROM patients
WHERE insurance_type IS NULL;


-- -----------------------------------------------------
-- Query 2: Negative Length of Stay
-- -----------------------------------------------------

SELECT *
FROM admissions
WHERE length_of_stay < 0;


-- -----------------------------------------------------
-- Query 3: Duplicate Appointment IDs
-- -----------------------------------------------------

SELECT
    appointment_id,
    COUNT(*) AS duplicate_count
FROM appointments
GROUP BY appointment_id
HAVING COUNT(*) > 1;