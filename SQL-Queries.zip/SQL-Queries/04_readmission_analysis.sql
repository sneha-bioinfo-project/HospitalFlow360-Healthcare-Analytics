-- =====================================================
-- HOSPITALFLOW360
-- READMISSION ANALYSIS
-- =====================================================

WITH ordered_admissions AS (

    SELECT
        patient_id,
        admission_date,
        discharge_date,

        LEAD(admission_date) OVER (
            PARTITION BY patient_id
            ORDER BY admission_date
        ) AS next_admission

    FROM admissions
)

SELECT
    patient_id,
    admission_date,
    discharge_date,
    next_admission,

    JULIANDAY(next_admission) -
    JULIANDAY(discharge_date)
    AS days_until_readmission

FROM ordered_admissions

WHERE
    JULIANDAY(next_admission) -
    JULIANDAY(discharge_date) <= 30;