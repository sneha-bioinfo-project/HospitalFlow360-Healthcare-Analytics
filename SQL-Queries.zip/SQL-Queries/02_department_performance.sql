-- =====================================================
-- HOSPITALFLOW360
-- DEPARTMENT PERFORMANCE ANALYSIS
-- =====================================================

SELECT
    d.department_name,
    COUNT(a.appointment_id) AS total_appointments

FROM appointments a

JOIN departments d
ON a.department_id = d.department_id

GROUP BY d.department_name

ORDER BY total_appointments DESC;